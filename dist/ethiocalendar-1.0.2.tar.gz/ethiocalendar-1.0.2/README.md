# ethiocalendar

Python module for Ethiopian calendar based date and time
